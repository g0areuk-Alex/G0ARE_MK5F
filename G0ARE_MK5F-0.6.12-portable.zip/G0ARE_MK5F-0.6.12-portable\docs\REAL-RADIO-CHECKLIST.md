# G0ARE_MK5F — first real-radio checklist

Use this sequence for the first connection to the Yaesu FT-1000MP Mark V Field. Complete the receive-only checks before trying PTT or the antenna tuner.

## 1. Build and identify the interfaces

1. Extract the release ZIP to a normal local folder on the Windows 11 PC.
2. Double-click `BUILD-WINDOWS.bat`. A successful build creates `dist\G0ARE_MK5F.exe` and reports that the CAT/RX-DSP/logbook/Morse self-tests passed. If it fails, retain `BUILD-LOG.txt`.
3. Connect the chosen USB-to-RS-232 CAT adapter and the SCU-17 to the PC, then open **Device Manager → Ports (COM & LPT)**.
4. Note the primary CAT-adapter COM port and both SCU-17/CP210x COM-port numbers so each separate session can select the intended interface explicitly.
5. In Windows recording devices, identify both sound interfaces: the small generic USB sound card for the live AF spectrum and the SCU-17 audio device reserved for digital modes.

## 2. Connect the radio safely

1. Make sure no other CAT program is running. Close programs such as WSJT-X, JTDX, Ham Radio Deluxe, Omni-Rig or logging software if they are configured to own the same COM port.
2. Connect the selected RS-232 CAT interface to the radio's rear **CAT** DB-9 using a normal straight-through RS-232 cable. Do not use a null-modem cable or a TTL-level lead.
3. Connect the radio AF output to the small generic USB sound card for the spectrum display. Keep the SCU-17 audio connection reserved for digital-mode software.
4. Leave the application's **DTR** and **RTS** boxes unticked for the first test.
5. Switch on the radio and put it in receive on a distinctive frequency, for example **14.20000 MHz USB**.

## 3. Receive-only CAT test

1. Start `dist\G0ARE_MK5F.exe` directly. On first run, save your callsign/name, confirm the two-second welcome screen, and ensure **Demo** is unticked.
2. Select the COM port for the CAT interface currently connected to the radio and press **CONNECT CAT**.
3. Within a second, the status should show **CONNECTED**, the display should read **14.200.00 USB**, and the CAT log should show repeating `TX` and `RX` byte records.
4. Rotate the radio's main tuning dial by a few kHz. Confirm that both the software frequency and mode follow front-panel changes.
5. Double-click the software frequency display and enter a nearby receive frequency. Confirm the radio follows it.
6. Select USB and then LSB in the software. Confirm the clicked button highlights immediately, the mode at the top-right of the frequency display changes, and the radio follows it.
7. Select VFO-B and VFO-A. Confirm the active button and frequency-display VFO label follow each selection and each VFO's frequency is read back.
8. Check that the analogue S-meter responds to receiver signals or noise.
9. Open **Station Tools → Meter Calibration…**. On VCC, capture a live CAT
   reading against the desired nominal **13.8 V** reference, save, and compare
   the main and large VCC readouts. Add measured references when available.
   Calibrate IC separately against a collector-current indication in amps.
   For RX, compare the needle and numeric reading on a steady signal and while
   it changes; both use the same displayed value. Confirm no-signal readings
   return to S0 and missing/stale replies are identified. Capture S0 and higher
   RX references if the default estimate differs from the radio's front panel.
9. Set a small clarifier value such as `+0.50 kHz`, press **RX ON**, and confirm the radio and app RX CLAR highlight agree. Repeat with **TX ON**, then **CLEAR**. Front-panel clarifier changes should feed back into the numeric value and highlights.
10. Toggle **MAIN LOCK** and **SUB LOCK** separately. Confirm the correct physical dial locks/unlocks and the matching app button remains highlighted only while its returned status bit is on.
11. Open **Themes** and try all five radio faces, then choose **Arctic Laboratory** from **Skins**. Confirm layout, frequency face and dial identity change while colour remains independently selectable and all controls remain usable.
12. Resize the main console below its normal size under each theme and confirm
    the workspace scrollbars reveal the left, centre and right controls rather
    than clipping them. Right-click **AUDIO** and one other advanced tab,
    choose its separate-window action, resize the new window, then close it and
    confirm the same live section returns to the tab strip.
13. Press and hold the computer **Space** bar only after fresh receive CAT
    feedback is visible; confirm the radio keys while held and immediately
    returns to receive on release. Confirm **Ctrl+Shift+S** sends **STOP TX**.
14. Do **not** use **HOLD PTT** or **START TUNE** during this first test.

## 4. AF spectrum, noise reduction, EQ and output test

1. Select the small generic USB sound-card recording input in the application and press **START AF**. Do not select the SCU-17 audio device.
2. Confirm that the spectrum heading names the numbered input and shows a changing RMS dBFS value. Select another input while AF is running and confirm the heading changes immediately.
3. Tune a voice or data signal and confirm that the spectrum, peak trace and waterfall respond. In the **VIEW** tab, adjust display gain, digital AF boost, scale floor and span until speech peaks are clear. Try **High · 4096 FFT / 2048 bins** and confirm that nearby tones separate more clearly than the Standard setting.
4. Adjust **SNR threshold**, **Noise reference trim** and **Waterfall range above noise**. Confirm the estimated noise-floor and SNR guide lines track the background and that a desired voice/data/Morse signal stands out without implying a wideband RF/IQ view.
5. With AF capture running, set **Device input level** and press **APPLY DEVICE LEVEL**. If the USB driver supports the Windows mixer control the app confirms the change; if not, use the independent digital boost or Windows Sound settings.
6. Open **AUDIO**, leave **ADAPTIVE NR** and **SIGNAL PASSBAND** on, set about 12 dB reduction and 180–3600 Hz. During a noise-only gap press **LEARN NOISE**, then compare NR on/off on a weak voice signal.
7. Try **Balanced**, then **High quality** or **Maximum** if the computer has headroom. Note the added processing latency and check that the audio remains continuous without dropped monitor buffers.
8. Move each graphic-EQ slider and confirm its value label and received sound respond. Test **FLAT** and **VOICE**.
9. Connect headphones, select their Windows output, leave **Output gain** at −12 dB and tick **MONITOR PROCESSED AF**. Confirm the selected output carries the filtered/equalised receiver audio. Only try speakers after this works quietly; speaker-to-input feedback can howl.
10. Stop AF and confirm monitored playback also stops. Restart AF and confirm monitoring remains off until explicitly enabled again.
11. Confirm the frequency labels remain visibly separated from the waterfall at the bottom of the spectrum plot.
12. If the trace is flat, confirm that Windows permits desktop applications to use the generic recording device and that the radio AF-output level is sufficient without overloading it.
13. CAT and AF are separate paths: correct CAT operation does not prove that audio is reaching Windows.

## 5. Morse decoder receive test

1. With AF running, tune a clean CW signal and open **MORSE**.
2. Tick **DECODE CW** and leave **AUTO TONE** on. Confirm the reported tone follows the strongest CW peak between 350 and 1200 Hz.
3. Set WPM near the sender's speed. Lower the gate for a weak signal or raise it if noise creates false symbols.
4. Tick **TRAINING OVERLAY** and confirm the waterfall shows the tracked tone plus rolling pairs such as `A ·—`. Untick it and confirm decoding continues in the transcript without the overlay.
5. Open **MORSE HELP** and confirm the letter, number and punctuation reference is readable.

## 6. Only after receive operation is proven

1. Connect a suitable dummy load, select minimum RF output power and verify the intended band/mode.
2. In **VIEW**, try Slow/Fast meter response and a two-second peak hold, then open **OPEN LARGE RX/TX METER**. Briefly press and hold **HOLD PTT**, then release it. Confirm both meters switch from RX to TX, power/ALC/SWR move, the callsign banner turns red with `TX`, and everything returns immediately to receive.
3. Repeat once using the computer **Space** bar, confirming that releasing Space unkeys the radio.
4. Leave **START TUNE** untested until the PTT release behaviour and load are confirmed.

## 7. Station tools receive test

1. Open **Station Tools → S-meter Band Scanner**, choose a small receive-only range, a 1 kHz step, 650 ms dwell and a deliberately low threshold such as S2. Confirm it stops on a qualifying signal and never keys the transmitter.
2. In N1MM Logger+, export a small test selection with **File → Export → Export ADIF to file**. Open **Station Tools → Logbook**, choose **IMPORT N1MM / ADIF**, review the dry-run accepted/duplicate/rejected counts and record details, then press **IMPORT ACCEPTED**. Confirm the summary, imported rows and timestamped pre-import CSV backup. Type a known callsign and confirm every prior contact/time appears newest-first. Preview/import the same file again and confirm the QSOs are identified as duplicates rather than added twice. Use **EXPORT SAFE CSV** with a test note beginning `=`, `+` or `@` and confirm the exported cell is protected while the logbook value remains unchanged.
3. Open **Station Tools → DX Cluster + Band Map**, choose a preset, verify the login matches the configured operator profile and connect. Internet/firewall policy may block Telnet; the host and port are editable if a public node has moved.
4. When spots arrive, double-click one only after checking that its frequency is appropriate for receive. Confirm the active VFO tunes and the red band-map line follows.
5. Open **Service / VRF Capability** and confirm it is informational only. Operate VRF from the radio front panel; do not attempt service-menu alignment during normal testing.

## 8. Separate FT8/SSTV session

1. Open the **DIGI** tab in `G0ARE_MK5F` and press **RELEASE CAT FOR DIGI**.
2. Confirm that the header says **CAT RELEASED**. The generic AF spectrum may continue running because it is a different sound device.
3. Start the FT8/SSTV application and configure it to use the released CAT COM port and the SCU-17 audio input/output.
4. When finished, close the digital application completely so it releases the COM port.
5. Return to the **DIGI** tab, press **END DIGI SESSION**, then press **CONNECT CAT** when you want the console back in control.

## If CAT does not connect

| Symptom | First check |
|---|---|
| No SCU-17 COM ports | Install/check the SCU-17 virtual COM driver, then reconnect USB. |
| “Access denied” | Another application already owns the selected COM port. |
| Repeated timeout | Try the other SCU-17 COM port; then check radio power and the straight-through RS-232 cable. |
| Frequency does not match | Save the first 20–30 lines of the CAT log and note the exact radio frequency. |
| CAT works but no spectrum | Select/check the generic USB sound-card input; this is independent of CAT and the SCU-17. |
| Spectrum works but no processed sound | Start AF, choose a valid output in **AUDIO**, then enable **MONITOR PROCESSED AF** at low gain. |
| Sound howls or echoes | Disable monitoring immediately; use headphones or prevent the selected input from hearing the speakers. |

For the next engineering pass, retain a screenshot of the application, the Windows names of both SCU-17 COM ports, and the first 20–30 CAT-log lines from a receive-only session.

## Reference

Yaesu's operating manual specifies the Field's built-in RS-232 level converter, a standard non-null-modem serial cable, 4800-bit/s CAT operation and five-byte command blocks: [MARK-V FT-1000MP Field operating manual](https://www.yaesu.com/Files/4CB893D7-1018-01AF-FA97E9E9AD48B50C/MARK-V%20FT-1000MP%20Field_OpMan.pdf).
