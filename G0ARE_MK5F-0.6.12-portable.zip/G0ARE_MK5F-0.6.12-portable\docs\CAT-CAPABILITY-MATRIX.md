# FT-1000MP Mark V Field CAT capability matrix

This matrix tracks the documented Mark V Field five-byte command families used by the console. Every command is sent as four argument bytes followed by the opcode.

| Function | Opcode | Console implementation | Notes |
|---|---:|---|---|
| Split on/off | `01h` | Main and VFO panels | State is read back from status flags. |
| Recall memory | `02h` | MEM/REP tab | Channels 1–113 accepted. |
| Memory enter/mask/unmask | `03h` | Reserved pending hardware validation | It changes stored memory state and the legacy table is internally ambiguous, so v0.1 does not transmit it. |
| Main/sub dial lock | `04h` | Main and RADIO panels | `00/01h` lock/unlock main and `02/03h` lock/unlock sub; command plus status verification is one atomic serial transaction and byte-3 feedback controls the highlights. |
| Select VFO-A/B | `05h` | Main panel | Uses the documented `00h`/`01h` selector; status read-back controls the VFO highlight and frequency label. |
| Copy memory to VFO | `06h` | MEM/REP tab | Uses selected memory. |
| VFO band step up | `07h` | RADIO panel | 100 kHz and 1 MHz forms. |
| VFO band step down | `08h` | RADIO panel | 100 kHz and 1 MHz forms. |
| Clarifier | `09h` | Left panel | RX/TX on/off, signed offset and clear; offset plus RX/TX flag feedback is decoded from operating-data bytes 5–6 and 9. |
| Set main VFO frequency | `0Ah` | Display, tuning dial and bands | 10 Hz CAT resolution. |
| Select mode | `0Ch` | Mode panel | All twelve documented mode values; bit 7 targets VFO-B and the returned low three mode bits drive the highlight. |
| Download pacing | `0Eh` | Automatic on connection | Reset to zero so status records fit the polling profile. |
| PTT | `0Fh` | RADIO tab and Space (Ctrl+Space remains compatible) | Momentary control with several fail-safe OFF paths. |
| Status update | `10h` | Automatic polling | Requests the 16-byte current operating record. |
| Electronic/contest keyer | `70h` | KEYER tab | Messages 0–3, CQ/ID, contest number, increment/decrement and monitor; every `70h` action passes the fresh-feedback transmit guard. |
| EDSP | `75h` | DSP/IF tab | Noise reduction and audio notch exposed; protocol helper supports further selections. |
| Tuner in/out | `81h` | RADIO tab | State read back from flags. |
| Start tuner | `82h` | RADIO tab | Warning/confirmation shown for a real radio. |
| Dual receive | `83h` | Main and RADIO panels | State read back from flags. |
| Repeater mode | `84h` | MEM/REP tab | Simplex, minus and plus. |
| Copy VFO-A to VFO-B | `85h` | Main panel | One-click A-to-B. |
| Set sub VFO frequency | `8Ah` | VFO panel | Exact VFO-B frequency entry. |
| IF bandwidth | `8Ch` | DSP/IF tab | Selects both main VFO-A IF filters with the documented `X1=00h` form. |
| Memory scan skip | `8Dh` | MEM/REP tab | Offered for memories 1–99. |
| Step VFO-A | `8Eh` | RADIO tab | Radio-defined small step up/down. |
| CTCSS selection | `90h` | MEM/REP tab | All 33 documented tones. |
| Read meters/panel controls | `F7h` | Automatic and DSP/IF tab | S, power, ALC, SWR, SHIFT, WIDTH, contour and NR. |
| Repeater offset | `F9h` | Protocol expansion point | UI currently sets repeater direction and tone; exact offset entry is next-stage scope. |
| Read status flags | `FAh` | Automatic polling | Six-byte form is tried first; the five-byte Mark V fallback contains three flags plus two ID bytes and is read completely if required. |

## Explicit non-CAT functions

The documented Mark V Field command table contains no opcode for entering or
writing the hidden alignment/service menu and no opcode for switching or tuning
the Variable RF Front-end Filter (VRF). G0ARE_MK5F therefore does not invent or
transmit service/VRF writes. **Station Tools → Service / VRF Capability** explains
the manual front-panel procedure and safety boundary. VRF remains operated by the
radio's physical `[VRF]` button and VRF/MEM CH knob on the supported 160–20 metre
bands.

## Polling profile

The console uses one serial transaction at a time and normally updates every 220 ms. A cycle requests the 16-byte operating record first, compatible status flags, main S-meter and RF power. Status-byte-1 bit 7 (`80h`) is the authoritative documented PTT/TX flag; a locally held CAT PTT request is also reflected immediately in the UI, while RF power remains display data and is not used to falsely block a new PTT request. ALC and SWR are then requested during transmit. The moving needles are interpolated at approximately 30 frames per second. A missing optional status or meter reply no longer blocks frequency and mode feedback.

## Bench-validation points

1. Confirm the returned 32-bit big-endian operating-frequency tuning word at a distinctive test frequency such as 14.20000 MHz. It is scaled at 16 counts per 10 Hz.
2. Confirm mode extraction for LSB, USB, CW, AM, FM, RTTY and packet.
3. Confirm the TX flag changes before power/ALC/SWR polling begins.
4. Record raw main S-meter values at S0, S5, S9, S9+20 and S9+40 using a calibrated signal generator if available.
   Enter those station comparisons in **Station Tools → Meter Calibration…**.
   The RX display and scanner thresholds share the saved reference mapping.
   VCC/IC use separately saved voltage/current references; nominal 13.8 V can
   be captured on the VCC tab. See [meter calibration](METER-CALIBRATION.md).
5. Record raw PO/SWR/ALC values against an external meter/dummy load at several power levels.
6. Confirm the correct 2nd- and 3rd-IF filter selection on the physical front-panel display.
7. Confirm that CAT PTT always releases on button release, Space release, window deactivation, disconnect and program exit.

## Protocol references used for the engineering prototype

- Yaesu/Vertex Standard MARK-V FT-1000MP operating-manual CAT chapter: five-byte structure, 4800 8N2 format, status records, meter selectors and opcode tables.
- Yaesu legacy Mark V Field product page: Field model identity and 100 W specification.

The mirrored manual text is used only as the source for implementing interoperability with the user's own radio; no manual text is bundled with the software.
