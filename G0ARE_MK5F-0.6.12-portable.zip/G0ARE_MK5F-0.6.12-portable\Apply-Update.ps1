[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string]$ArchivePath,
    [Parameter(Mandatory = $true)] [string]$TargetDirectory,
    [int]$ProcessId = 0,
    [switch]$Restart,
    [switch]$Quiet
)

$ErrorActionPreference = 'Stop'

function Show-UpdateError([string]$Message) {
    if (-not $Quiet) {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show($Message, 'MK5F update', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    }
    exit 1
}

try {
    $archive = [System.IO.Path]::GetFullPath($ArchivePath)
    $target = [System.IO.Path]::GetFullPath($TargetDirectory)
    if (-not (Test-Path -LiteralPath $archive -PathType Leaf)) { Show-UpdateError 'The verified update archive could not be found.' }
    if (-not (Test-Path -LiteralPath $target -PathType Container)) { Show-UpdateError 'The installed MK5F directory could not be found.' }
    if (-not (Test-Path -LiteralPath (Join-Path $target 'G0ARE_MK5F.exe') -PathType Leaf)) { Show-UpdateError 'The target directory is not a valid MK5F installation.' }

    if ($ProcessId -gt 0) {
        $deadline = [DateTime]::UtcNow.AddSeconds(35)
        while ([DateTime]::UtcNow -lt $deadline) {
            $running = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
            if (-not $running) { break }
            Start-Sleep -Milliseconds 250
        }
        if (Get-Process -Id $ProcessId -ErrorAction SilentlyContinue) { Show-UpdateError 'MK5F did not close in time. The update was not applied.' }
    }

    $work = Join-Path ([System.IO.Path]::GetTempPath()) ('MK5F-update-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $work | Out-Null
    try {
        Expand-Archive -LiteralPath $archive -DestinationPath $work -Force
        $packageExecutables = @(Get-ChildItem -LiteralPath $work -Filter 'G0ARE_MK5F.exe' -File -Recurse)
        if ($packageExecutables.Count -ne 1) { Show-UpdateError 'The update archive did not contain exactly one MK5F executable.' }
        $packageRoot = $packageExecutables[0].Directory.FullName

        foreach ($item in Get-ChildItem -LiteralPath $packageRoot -Force) {
            if ($item.Name -ieq 'G0ARE_MK5F.exe' -or $item.Name -ieq 'Apply-Update.ps1') { continue }
            Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $target $item.Name) -Recurse -Force
        }

        $incomingExe = Join-Path $target 'G0ARE_MK5F.exe.update'
        Copy-Item -LiteralPath $packageExecutables[0].FullName -Destination $incomingExe -Force
        Move-Item -LiteralPath $incomingExe -Destination (Join-Path $target 'G0ARE_MK5F.exe') -Force
    }
    finally {
        if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue }
    }

    if ($Restart) { Start-Process -FilePath (Join-Path $target 'G0ARE_MK5F.exe') -WorkingDirectory $target }
    if (-not $Quiet) {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show('MK5F was updated successfully and has been restarted.', 'MK5F update', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    }
    exit 0
}
catch {
    Show-UpdateError ('The MK5F update could not be applied: ' + $_.Exception.Message)
}
