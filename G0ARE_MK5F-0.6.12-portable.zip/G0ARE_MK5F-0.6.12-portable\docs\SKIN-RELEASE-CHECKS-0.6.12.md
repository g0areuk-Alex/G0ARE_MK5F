# 0.6.12 release checks

Windows Framework64 C# build completed with warning level 4 and passed the
complete `--self-test --ui-stress` suite on 9 October 2026. All checks below use
simulated CAT or test audio drivers; no physical CAT connection or sound-card
capture was started.

- RX: all 256 CAT counts, agreement between the animated text and needle,
  every printed scale label, immediate S0/peak reset, unavailable replies and
  stale feedback.
- Calibration: nominal 13.8 V capture, current references in amps, offset and
  multi-point interpolation, extrapolation status, malformed/duplicate/reversed
  references, real settings-file round trips, and full 32-point tables.
- Calibration controls: actual live-reference button clicks on VCC, IC and
  RX tabs; stale and receive-side IC capture disabled; save validation.
- Meter selection: PO, SWR, ALC, IC, VCC, MIC and TUN, bounded read-only polling,
  source isolation, large-meter AUTO, idle and timeout handling.
- Viewports: 253 layout/skin cases, plus 3744 frequency-digit hit regions
  across 12 layouts, 13 skins and three window sizes. Menu descenders, icons,
  full screen, mixed and partial wheel steps, and AF shortcuts passed.
- Lifecycle: repeated close/restore cycles for all nine detached sections and
  station windows, sustained DSP/UI coalescing, raw/processed monitoring, shared
  Learn controls, and independent PTT release while audio cleanup waits.

The first full runs exceeded the 150 ms close-dispatch limit. Stage measurements
identified 216 ms spent synchronously disabling the console's control tree.
The closing screen now covers the full client area and holds keyboard focus,
avoiding that recursive work while device release continues. In the final full
run, AF stop dispatched in **12 ms** and Close in **11 ms**, with deliberately
slow test drivers. Repeated Close requests still wait for the same cleanup.

Native previews were checked at 1600×1040, 1366×728 and 800×560. The packaged
gallery includes the calibration screen, seven console designs, four selected
meter examples, and two compact-console views. Their CAT readings and physical
references are illustration data, never persisted to station settings.

Installer/portable manifests, hashes and isolated extraction are recorded in
`tmp/meter-release-2026-10-09/release-verification.txt`. Packaging preserves the
previous release and user station data.

Physical acceptance remains at the station: compare RX indications with the
radio and save reference points if needed; capture nominal 13.8 V on VCC and
provide an independent IC reference. A nominal-voltage reference does not
independently measure actual supply voltage. Instructions are in
[Meter Calibration](METER-CALIBRATION.md).
