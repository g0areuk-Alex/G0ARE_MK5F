# G0ARE_MK5F — Feature evidence register

Date: 3 October 2026  
Product baseline: v0.6.3 engineering release  
Evidence build executable SHA-256: `B1FBD4B472D9CDD23F836AC7BEC806BE4F0F7A6B513AD68E2C91427053323498`  
Evidence build log SHA-256: `9D775E1A8C9A34AD6984879BC630CE543CEC2F670DEED795DD0B37EFCC1E768B`  
Source revision: not available; this workspace has no Git metadata or other
source revision identifier.

This register implements the handover's P0 provenance/evidence action. A source
implementation or a deterministic simulator test is not treated as proof of
physical-radio, Windows-device, accessibility, security, installer or owner
acceptance behaviour.

The redacted Diagnostics / About report is implemented as a requested support
artifact. It excludes QSO/audio content, credentials, full user paths and CAT
traces by default. The VIEW tab also includes a read-only Meter Diagnostics
report that records raw CAT meter fields and visual mappings without claiming
RF calibration.

Status meanings:

- **Verified software** — implementation and a focused local/self-test provide
  evidence for the stated scope.
- **Implemented, integration open** — code is present, but the required device,
  visual, performance or failure scenario has not been run.
- **Intentionally absent** — the capability is not shipped, or is deliberately
  excluded as a safety boundary.
- **Unverified/absent** — no trustworthy implementation or external evidence was
  found in this workspace.

## Build provenance

| Item | Evidence |
|---|---|
| Product/runtime | `VERSION.txt`; Windows executable targeting .NET Framework 4.8 |
| Build command | `cmd.exe /d /c "BUILD-WINDOWS.bat --no-pause"` |
| Compiler | `C:\WINDOWS\Microsoft.NET\Framework64\v4.0.30319\csc.exe` |
| Source input | `src\*.cs`, compiled by `BUILD-WINDOWS.bat` with `/recurse:*.cs` |
| Automated result | Build log and `dist\G0ARE_MK5F.exe --self-test --ui-stress` report success; the UI/system stress pass covers all five layouts, six skins, nine live sections, five auxiliary windows, sustained DSP/UI pressure and five repeat runs; release/update dialogs and manifest validation are also self-tested |
| Release artifact | `dist\G0ARE_MK5F-0.6.3-portable.zip` with a SHA-256 manifest and sidecar, plus the single-file `dist\G0ARE_MK5F-0.6.3-Setup.exe` installer and sidecar |
| Source provenance artifact | Bundled `SOURCE-MANIFEST.txt` hashes the build scripts, icon, installer stub, updater/setup helpers, `VERSION.txt`, app manifest, map data and every `src\*.cs`; bundled `BUILD-ENVIRONMENT-2026-09-05.md` records the observed compiler/runtime and native/network surfaces; it records that no Git revision is available |
| Distribution limits | Installer and updater are implemented and locally exercised but unsigned; public feed hosting, publisher identity, clean-machine UAC/shortcut review, rollback and owner acceptance remain open |

Local evidence IDs used below:

- **S01** — clean build plus executable self-test.
- **S02** — CAT command/parser, transmit classification and simulator PTT state.
- **S03** — FFT, passband and adaptive-noise DSP checks.
- **S04** — ADIF parsing including malformed/truncated/unterminated-record rejection, malformed-logbook-row visibility, staged preview/accepted-duplicate-rejected counts, stale-plan duplicate recheck, durable logbook write, spreadsheet-safe CSV and import/duplicate checks.
- **S05** — backup manifest, isolated restore, appearance-settings persistence and last-known-good corrupt-settings recovery, plus tamper/traversal rejection.
- **S06** — generated Morse SOS decode and Help mapping/completeness checks.
- **S10** — bounded local Morse practice-tone generation and exact-answer scoring
  checks; the UI path is explicitly local-output-only and does not call CAT.
- **S11** — deterministic Meter Diagnostics report check covering raw fields,
  stale-state language, visual dynamics and uncalibrated-value boundaries.
- **S12** — versioned station-routing settings persistence, exact
  name/device-ID matching, no silent endpoint fallback and reserved-SCU-17
  selection checks; the wizard's local simulator path uses receive-only state.
- **S13** — bounded Morse replay-buffer and decoder-text snapshot checks,
  including explicit clear behavior and the local-output-only replay path.
- **S14** — bounded generated-AF session chunking checks; generated receive
  audio drains through a local buffer without Windows input, CAT or TX I/O.
- **S15** — corrected raw TX power mapping checks; raw values 120 and 60 map to
  full and half scale respectively through the shared main/pop-out semantics.
- **S16** — RX S-meter zero-floor/full-scale checks; the calibrated idle floor
  maps to S0/zero deflection, raw 255 remains full scale, and the scanner uses
  the same converted S-unit thresholds.
- **S17** — station-desk UI construction/layout check; the Logbook and DX
  Cluster tabs are constructed and selected without an invalid splitter
  distance.
- **S18** — high-resolution spectrum checks; a rolling 8192-point display
  window and 2048-bin output isolate a deterministic 1.234 kHz tone at the
  finer expected frequency resolution.
- **S19** — selectable RX NR quality check; the Maximum mode selects the
  4096-point processing window and accepts the extended reduction range.
- **S20** — deterministic advanced-section detach/restore check; a live tab page
  is hosted in a sizable `SectionWindowForm`, then restored to its original
  `TabControl` when the window closes.
- **S21** — settings/help UI check; HoverHelp persists through the versioned
  settings file and the scrollable Quick Help/Keyboard Shortcuts form constructs
  with its documented minimum size.
- **S22** — DX spot Maidenhead/split parsing, SWR auxiliary colour thresholds
  and resizable World Map form construction.
- **S23** — bundled Natural Earth country geometry is loaded into the World
  Map, the country-code label layer is constructed, and the map viewport starts
  at a full-world zoom level with reset/zoom/pan interaction paths available;
  exact cluster locators remain exact and callsign-only regional fallbacks are
  marked estimated.
- **S24** — repeatable UI stress pass; all five layout themes and six skins are
  applied, each theme's expected main-grid cell map is checked, visible child
  controls are rejected if they have zero drawable bounds, all nine live
  advanced sections and five auxiliary windows are opened, resized, re-skinned,
  repeat-opened and closed twice, and every live section is restored to the
  hidden registry without a layout freeze.
- **S25** — RX/TX meter response and appearance-refresh checks; TX uses a faster
  response factor than RX at every user setting, the needle reaches a new
  sample sooner in the deterministic control test, and a skin/theme refresh
  immediately repaints both meters from their last valid targets. The UI stress
  path repeats this while all themes, skins and auxiliary windows are live.
- **S26** — safe QRZ URL construction from validated station callsigns, plus
  final main-form close verification after the full UI stress window lifecycle;
  the close path stops timers, skips detached-page restore churn and does not
  leave the UI-owned CAT/cluster callbacks active.
- **S27** — version-2 station-settings round-trip covering validated control
  choices, main-window placement, detached/auxiliary window layouts, open
  state, last-active-window tracking, tab selection and large-meter
  Always-on-top state; normal startup restoration also clamps invalid geometry.
- **S28** — RX S-meter recalibration checks; the raw-32 idle floor and low-end
  S0 readout deadband preserve zero deflection while raw 255 remains full scale
  and the scanner continues to use the same conversion.
- **S29** — sustained DSP/UI responsiveness check; 36 real receive blocks use
  the rolling spectrum accumulator, coalesced visual snapshots and cached
  waterfall path while 180 live state refreshes are drained under a 15-second
  guard.
- **S30** — main-window pressure audit; debounced settings writes, guarded
  workspace normalisation, conditional meter/control repaints and bounded
  DX-cluster batch consumption are present in the audited source paths.
- **S31** — repeatability check; five additional `--self-test --ui-stress`
  executable runs exited successfully after the performance/lifecycle pass.
- **S32** — release/update self-test; station-settings round-trip includes
  update preference fields, valid manifests are parsed, newer versions are
  detected, downgrades and other products are rejected, and the release-notes/
  update dialog controls construct successfully.
- **S33** — installer build and isolated install check; the single-file setup
  stub was compiled with the MK5F icon, unpacked into an isolated directory,
  installed the executable/icon/map/updater payload and the installed copy
  passed `--self-test --ui-stress`.
- **S34** — SWL catalogue check; EiBi fixed-width AM/SSB rows, UTC hours/day
  activity, segmented MHz formatting, numeric sort comparator, semicolon/CSV-
  style FM import, custom-station persistence, out-of-range FM tuning
  rejection, NOAA/BOM-style HF weather voice/radiofax parsing and resizable
  SWL form construction pass deterministically without requiring an online
  feed or physical CAT radio.
- **S35** — live SWL source check; the current EiBi schedule, NOAA/NWS USCG
  marine page and Australian BOM HF marine page each download and parse into
  usable catalogue rows during the release validation pass.
- **S36** — SWL favourites/country/scan check; country designators expand to
  full names, common imported ISO aliases are handled, favourite identity is
  stable across source-refresh keys, the My Favourites tab and All Stations tab
  construct with the signal column and scan controls, and the deterministic
  SWL UI/self-test completes without requiring hardware.
- **S37** — ordered/resumable SWL scan check; every grid column is configured for
  programmatic sorting, the active column/direction is reused as the scan order,
  a stopped station's stable key is retained for `CONTINUE SCAN`, and the next
  scan begins after that row. Sort/filter/tab changes pause safely and preserve
  the continuation key; the deterministic SWL/UI self-test completes without
  requiring hardware.
- **S07** — all-match callsign history filtering and newest-first ordering.
- **S08** — portable manifest and ZIP sidecar verification.
- **S09** — bounded safe `--demo` and `--safe-mode` startup smokes on this Windows host; controlled cleanup.

Rows marked as software-verified refer to these IDs and to the two hashes above;
the evidence location is the source path named in the row plus
`BUILD-LOG.txt`/`docs\AS-BUILT-AUDIT-2026-09-05.md`.

## Capability register

| ID | Status at this build | Source/test evidence | Required evidence still missing |
|---|---|---|---|
| IDN-01 | Implemented, integration open | `Program.cs`, `MainForm.cs`, `OperatorProfile.cs`, `VERSION.txt`; product and default profile strings are present | Visual title/splash/About/package review and owner acceptance |
| PLT-01 | Verified software | **S01**; `BUILD-WINDOWS.bat`, `app.manifest`, `VERSION.txt`; executable built and self-tested on this Windows host | Clean-machine/runtime matrix |
| CAT-01 | Implemented, integration open | **S01/S02**; `CatProtocol.cs`, `RigLink.cs`, `MainForm.cs`; parser, frequency/mode/PTT command generation, stale-state and simulator readback tests pass | FT-1000MP Mark-V Field CAT trace, reconnect and per-command readback tests (V03–V13) |
| AUD-01 | Implemented, integration open | `MainForm.cs`, `AudioAndDsp.cs`; device selection and reserved SCU-17 check are present | Actual endpoint/channel/rate and unplug/replug tests (V14–V15) |
| AUD-02 | Verified software for deterministic DSP scope | **S03/S19**; `RxAudioProcessing.cs`, `MainForm.cs`, `Program.cs`; stationary-noise self-test passes and Balanced/High/Maximum processing-window selection is covered | Speech/CW/noise corpus, CPU headroom, latency and live intelligibility results (V16) |
| AUD-03 | Verified software for deterministic DSP scope | **S03**; `RxAudioProcessing.cs`, `Program.cs`; passband tone rejection self-test passes | Sweep, clipping and hardware-path measurements (V17) |
| AUD-04 | Implemented, integration open | `RxAudioProcessing.cs`, `MainForm.cs`; eight-band EQ controls and processing exist | Band-centre/gain/headroom measurement (V18) |
| AUD-05 | Implemented, integration open | `AudioAndDsp.cs`, `MainForm.cs`; explicit output/monitor controls and dropped-buffer reporting exist | Windows routing, mute and loopback/feedback tests (V19) |
| AUD-06 | Implemented, integration open | `MainForm.cs`; RAW FFT (A/B) selects raw input for spectrum/waterfall while monitor and Morse remain processed | Live raw/processed intelligibility and device-routing comparison (V19, V20) |
| VIS-01 | Implemented, integration open | **S01/S03/S18**; `AudioAndDsp.cs`, `VisualControls.cs`, `MainForm.cs`; rolling 1024–8192-point processed FFT, up to 2048 display bins, tracked noise/SNR lines and waterfall-range controls exist; high-resolution FFT self-test passes | Live source/timestamp/scale/pause/resize validation, display preference and CPU review (V20–V21) |
| MOR-01 | Verified software for deterministic clean signal | **S01/S06**; `MorseDecoder.cs`, `Program.cs`; generated 700 Hz SOS decode passes | Labelled corpus, silence/noise/weak-signal/manual-send metrics (V22–V24) |
| MOR-02 | Verified software mapping; visual integration open | **S06**; `MorseAlphabet` and `MorseHelpForm`; self-test checks 54 entries and representative mappings | Rendered Help review against the selected reference and supported-symbol wording (V25) |
| MOR-03 | Implemented, integration open | **S01/S06**; `MainForm.cs`, `SpectrumControl`; training toggle only changes overlay text path | Live alignment, resize/pause and independent-toggle test (V26) |
| MOR-04 | Implemented, integration open | **S10**; `MorsePractice.cs`, `MainForm.cs`; bounded local practice-tone generation, progressive character groups and exact-answer scoring; no CAT/keyer route; self-test passes | Actual speaker/headphone output, acoustic-feedback review and visual/keyboard acceptance |
| MOR-05 | Implemented, integration open | **S13**; `MorseReplay.cs`, `MainForm.cs`; opt-in 8-second processed-AF rolling buffer, delayed live-answer hiding, explicit replay/reveal/clear controls and no CAT/keyer/TX path | Actual AF capture/output review, replay intelligibility, keyboard/accessibility and memory/soak measurements (V22–V24, V57) |
| LOG-01 | Implemented, integration open | **S01/S04**; `StationTools.cs`, `AdifPreviewForm.cs`; durable atomic writes, malformed-logbook-row warning, staged ADIF preview/commit, malformed/truncated/unterminated-record rejection, spreadsheet-safe CSV, import/export, rollback and limits; self-test passes | Full edit/delete/interrupt and large-log performance tests (V29, V31, V58) |
| LOG-02 | Implemented, integration open | **S07**; `StationHistory` in `StationTools.cs`; self-test proves all matching records, partial callsign input, newest-first ordering, explicit alias exact matches and preservation of stored callsigns | UI/keyboard/performance review with a 100,000-record fixture and owner review of alias rules (V27–V28) |
| MET-01 | Implemented, integration open | **S15/S16/S22/S28**; `MainForm.cs`, `VisualControls.cs`, `LargeMeterForm.cs`; shared raw-power mapping, recalibrated RX zero floor/deadband, RX/TX/stale labels, lower-left raw fields and enlarged SWR/ALC auxiliary readouts with safety colours are explicit | Physical meter comparison and calibration decision (V32) |
| MET-02 | Implemented, integration open | **S25**; `MainForm.ApplyMeterDynamics`, `AnalogMeter.ResponseFactor`, `MainForm.SetMeterPollCadence`; RX retains Slow/Normal/Fast/Instant factors, TX uses a faster factor and transmit polling changes to 105 ms while RX remains 220 ms | Controlled input timing on the actual radio, CAT response-time/CPU review and owner visual check (V33) |
| MET-03 | Implemented, integration open | `AnalogMeter.PeakHoldMilliseconds`, large-meter propagation and reset-on-state-change are present | Hold/reset UI and live behaviour review (V33) |
| MET-04 | Implemented, integration open | **S11/S16/S28**; `MeterDiagnosticsForm.cs`, `MainForm.cs`, `VisualControls.cs`; raw CAT bytes, normalized visual state, recalibrated RX zero/deadband/full-scale mapping, stale status and visual-only peak reset are exposed without calibration claims | Rendered UI review, physical meter comparison and calibration decision (V32–V33) |
| UI-01 | Implemented, integration open | **S17/S20/S21/S22/S23/S24/S26/S27/S29/S30/S31**; `MainForm.cs`, `HelpUi.cs`, `SectionWindowForm.cs`, `StationTools.cs`, `VisualControls.cs`, `WorldMapForm.cs`; five layout themes, independent skins, scrollable themed workspace/section hosts, fixed-width meter cells, launcher-only advanced area with left-click live-section detachment, foreground activation for owned windows, session placement/restore, station-tool launchers, UTC clock, menu shortcuts, Quick Help, HoverHelp, full-window Natural Earth World Map, dual-map QRZ context actions and bounded live UI/DX-cluster update paths are present | All operations under every theme, scaling, scroll-position, shortcut, tooltip, launcher/restore, live telnet burst, map readability, zoom/pan, session restore on the owner's multi-monitor layout, QRZ/browser behavior, country-label accessibility and physical CAT split checks (V34–V35, V61) |
| DX-01 | Implemented, integration open | **S22/S23**; `StationTools.cs`, `WorldMapForm.cs`, `MapData\ne_50m_admin_0_countries.geojson`, `MainForm.cs`; shared DX-cluster spot stream, Natural Earth country geometry, Mercator/grid rendering, subdued country-code labels, full-window docking, exact-versus-estimated Maidenhead handling, search, wheel zoom, drag pan, marker click tuning and ordered simplex/split CAT sequence are present | Reachable telnet endpoint, locator accuracy, spot freshness, map visual/accessibility review and physical VFO-A/VFO-B split readback (V61) |
| SWL-01 | Implemented, integration open | **S34/S35/S36/S37**; `SwlStation.cs`, `MainForm.cs`, `StationSettings.cs`, `StationBackup.cs`; resizable SWL pop-out, seasonal EiBi plus NOAA/NWS/BOM update sources, segmented MHz formatting, numeric frequency sorting on every grid column, searchable AM/SSB/CW/FM catalogue, USB/LSB utility/data/weather rows, full country-name column, persistent My Favourites, CAT S-meter signal scanning for both station tabs in the selected grid order, resumable `CONTINUE SCAN`, UTC/local/source schedule fields, custom add, CSV/TSV/semicolon import, persistent catalogue/backup and receive-first CAT frequency/mode tuning are present | Online-source reachability/current-season accuracy over time, authorised FM/MW list import, owner station review, CAT readback, physical signal-scan threshold/dwell/order review, audio/data intelligibility and the Mark V's physical FM boundary (V62) |
| UI-02 | Implemented, local profile only | `OperatorProfile.cs`; callsign/name persistence and profile dialog exist | Profile-switch/attribution acceptance; this is not an authenticated account |
| UI-03 | Implemented, integration open | **S01/S09/S21/S27/S30/S32**; `OperatorProfile.cs`, `StationSettings.cs`, `MainForm.cs`, `Program.cs`, `ReleaseAndUpdate.cs`; first-run profile, splash, release-notes popup, validated appearance/control/window-session/HoverHelp/update-preference persistence, debounced normal preference writes, last-known-good corrupt-settings recovery and `--safe-mode` recovery path exist | Visual corrupt-settings/safe-mode, tooltip, shortcut, release-popup, non-blocking startup and long-session persistence review (V36) |
| UI-04 | Implemented, integration open | `MainForm.UpdateStateDisplay`; banner follows fresh feedback and distinguishes TX unknown | Actual requested/observed/stale physical-radio scenarios (V37) |
| UI-05 | Implemented, integration open | **S12**; `StationHealthWizardForm.cs`, `StationSettings.cs`, `StationDeviceSelection.cs`, `MainForm.cs`; receive-first endpoint inventory, SCU-17 warning, local simulator check and non-secret name/ID routing preference persistence with no silent unidentified-device fallback | Actual CAT/audio endpoint validation, rendered wizard/accessibility review and owner acceptance (V14–V15, V36) |
| SRV-01 | Intentionally read-only | `MorseUi.cs` `ServiceVrfForm`; screen documents supported CAT boundary and sends no service writes | Visual review and retained CAT trace (V38) |
| SRV-02 | Intentionally absent | No hidden-menu/service write path found; screen explicitly says unsupported | None unless a documented radio capability is supplied |
| SRV-03 | Intentionally absent | No VRF write/tune path found; physical-control limitation is documented | None unless a documented capability and owner decision are supplied |
| BLD-01 | Verified software | `BUILD-WINDOWS.bat`, `BUILD-LOG.txt`, `docs\AS-BUILT-AUDIT-2026-09-05.md` | Source revision relationship cannot be stronger without repository metadata |
| INS-01 | Verified software for local install scope | **S33**; `PACKAGE-INSTALLER.ps1`, `installer\InstallerStub.cs`, `Install-MK5F.ps1`, `BUILD-ICON.ps1`; single-file per-user setup embeds the portable payload, installs `MK5F` icon/shortcut identity and the installed executable passes the full self-test | Clean-machine installer/UAC/shortcut review, repair/uninstall procedure, signing and owner acceptance (V45–V47) |
| UPD-01 | Implemented, integration open | **S32/S33**; `ReleaseAndUpdate.cs`, `Apply-Update.ps1`, `UPDATE-MANIFEST.example.json`; configurable HTTPS manifest, product/version/hash/source validation, operator confirmation, post-exit apply/restart helper and installed updater payload are present | Public HTTPS feed, signed/authenticated release, interruption recovery, rollback, downgrade/clean-machine and owner acceptance tests (V48–V51) |
| BAK-01 | Implemented, integration open | **S01/S05**; `StationBackup.cs`, `StationTools.cs`; manifest/SHA-256, isolated test restore, settings/profile/logbook scope, pre-restore safety backup and malicious-backup rejection; self-test passes | Clean-user/PC recovery, retention/scheduling and disaster-recovery acceptance (V52–V56) |
| USR-01 | Intentionally absent beyond local profile | `OperatorProfile` is a display/operator profile only; no roles or authorization service found | Product decision and permission model if shared-station accounts are required (V39–V40) |
| SEC-01 | Implemented, assurance open | Bounded ADIF/logbook/backup parsing, allowed restore paths, no secrets in data backup, receive-first TX guard | Static review, malicious-file tests, permissions and network observation (V42–V44, V54–V55) |
| VER-01 | Unverified/absent | No email, licence or callsign verification service found | Explicit product scope and any approved verification protocol (V41) |
| TST-01 | Verified software for local tests only | **S01–S37**; `Program.cs` covers CAT/DSP/logbook/ADIF/Morse/practice/replay/diagnostic-AF/backup/settings/history/meter diagnostics/station health, corrected power mapping, recalibrated RX zero-floor/deadband mapping, SWR colour thresholds, exact DX locator and region-appropriate estimated fallback parsing, Natural Earth World Map construction, station-desk layout, validated QRZ URL construction, version-2 control/session/update settings round-trip, advanced-section detach/restore, all-theme meter sizing, foreground window activation path, separate faster TX meter response, theme-refresh repaint, bounded audio/UI update flow, cached waterfall rendering, DX-cluster batch path, SWL EiBi/NOAA/BOM parsing, segmented MHz formatting, numeric frequency sorting on every column, country-name expansion, favourite identity, selected-column ordered scan/resume controls and catalogue persistence, multi-window lifecycle stress, sustained DSP/UI responsiveness, five repeat runs, main-form close, release/update dialog and manifest validation; isolated installer extraction and installed-copy self-test also pass; physical CAT/audio and long-duration soak remain open | Traceable station test register, eight-hour physical/device soak, multi-monitor session-restore review, live telnet/source reachability over time, owner station/weatherfax accuracy/audio review, Chrome/default-browser check, clean-machine installer/UAC/shortcut/update/rollback review, signed feed and owner acceptance (V57–V62) |
| PERF-01 | Verified software for local stress scope | **S29/S30/S31**; `MainForm.cs`, `AudioAndDsp.cs`, `VisualControls.cs`, `StationTools.cs`; newest-only audio UI snapshots, display-throttled FFT, cached bulk waterfall bitmap, debounced settings writes, non-forced workspace painting, conditional repaint guards, bounded DX-cluster batches and repeatable UI/system stress pass are present | Eight-hour physical audio/CAT soak, CPU/latency measurements at each NR/FFT quality, live telnet burst and owner responsiveness review |
| INT-01 | Implemented, integration open | `StationTools.cs` includes a Telnet DX-cluster client and separate CAT/audio digital-session workflow | Endpoint policy/reachability and external-application coexistence tests (V59) |

## Executed local checks

| Check | Result |
|---|---|
| Build and self-test | Passed; see `BUILD-LOG.txt` |
| Direct executable self-test | Passed; `dist\G0ARE_MK5F.exe --self-test` |
| CAT parser/command and simulator state checks | Passed inside self-test |
| RX FFT, passband and adaptive-noise checks | Passed inside self-test |
| ADIF parse, malformed/truncated/unterminated-record rejection, malformed logbook-row warning, staged preview/commit, duplicate logic and spreadsheet-safe CSV checks | Passed inside self-test |
| Durable logbook and all-match history check | Passed inside self-test |
| Morse SOS and Help mapping checks | Passed inside self-test |
| Morse practice generation and exact-answer scoring | Passed inside self-test; local-output-only UI path remains integration-open |
| Diagnostic AF generated receive stream and bounded chunking | Passed inside self-test; synthetic/no-Windows-input/no-CAT-TX boundary remains explicit |
| DX spot grid/split parsing, exact/estimated callsign-grid handling, SWR colour thresholds, Natural Earth country geometry and World Map construction | Passed inside self-test; live telnet, visual map/zoom/pan and physical split tuning remain integration-open |
| Meter Diagnostics raw/stale/calibration-boundary report | Passed inside self-test; visual and physical-radio validation remain integration-open |
| Corrected TX raw-power mapping | Passed inside self-test; raw 120 = full scale and raw 60 = half scale, while physical RF calibration remains open |
| Station Health routing/settings and local simulator check | Passed inside self-test; physical endpoint and rendered-wizard validation remain integration-open |
| Morse replay bounded-window and clear/reveal data path | Passed inside self-test; actual AF/output and delayed-reveal UI validation remain integration-open |
| Backup manifest, isolated restore, settings persistence/recovery and malicious-input rejection | Passed inside self-test |
| Portable manifest and ZIP sidecar | Passed for the v0.6.3 package; 15 manifest entries, zero mismatches and a matching SHA-256 sidecar |
| Single-file installer build and isolated install | Passed for the v0.6.3 package; `G0ARE_MK5F-0.6.3-Setup.exe` embeds the payload/icon, installed into an isolated directory without shortcuts/launch side effects, and the installed executable passed `--self-test --ui-stress` |
| SWL catalogue/parser/UI | Passed inside self-test and live source validation; EiBi/NOAA/BOM AM/USB/LSB/weatherfax rows, segmented MHz formatting, numeric frequency sorting on every grid column, full country-name column, persistent favourites, CAT S-meter station scanning for both tabs in the selected order, resumable continuation, UTC/local/source schedule fields, CSV/TSV/semicolon import, custom persistence, active-now safeguards and the 0.1–30 MHz tuning guard are covered; long-term source reachability, station accuracy, physical CAT/audio and FM coverage remain integration-open |
| Release notes/update service | Passed inside self-test and source audit; first-run release-notes/update dialogs construct, settings persist update preferences, manifests reject wrong products/downgrades/invalid hashes and accept a newer valid version; public feed/download/apply/rollback remain integration-open |
| MK5F application thumbnail/icon | Passed locally; `BUILD-ICON.ps1` generates `assets\MK5F.ico`, the app is compiled with `/win32icon` and the installer/portable payload carries the icon |
| Safe `--demo` and `--safe-mode` startup smokes | Each launched for three seconds without a radio and was then closed by controlled process cleanup |
| All-theme/multi-window UI stress | Passed; `dist\G0ARE_MK5F.exe --self-test --ui-stress` completed all layout/skin/resize/re-skin/repeat-open/close-restore cycles without a freeze |
| Main-window responsiveness stress | Passed; the same self-test exercised 36 real synthetic receive blocks, display-throttled high-resolution FFT/waterfall updates and 180 live state refreshes under a 15-second guard; five additional executable repeat runs also exited successfully |
| UI pressure audit | Passed for local software scope; audio visual updates are newest-only, settings saves are debounced, workspace normalisation is re-entry guarded, unchanged controls avoid repaint work and DX-cluster lines are bounded/batched before map/grid refresh |
| RX/TX meter response and theme-refresh checks | Passed inside self-test and UI stress; TX response settles faster than RX, transmit polling uses 105 ms, and skin/theme refresh restores both needles to their last valid targets |
| Orderly close and QRZ URL checks | Passed inside self-test/UI stress; the main form closes after the full window lifecycle and validated callsigns produce QRZ URLs; actual Chrome tab opening remains an owner/browser integration check |
| Session settings and window-layout checks | Passed inside self-test; version-2 settings round-trip validates control choices, window bounds/state, open-window records and last-active-window tracking; actual multi-monitor visual restoration remains an owner integration check |
| RX idle-floor recalibration | Passed inside self-test; raw 32 and the low-end display deadband resolve to S0/zero deflection while raw 255 remains full scale |

The handover's V01–V60 register remains an acceptance plan. The rows requiring
the actual Field, audio interfaces, visual inspection, public installer/update
hosting, clean-machine recovery or owner sign-off are intentionally not marked
passed here.
