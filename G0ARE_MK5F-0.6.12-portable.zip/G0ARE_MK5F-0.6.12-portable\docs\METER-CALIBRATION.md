# Radio meter calibration — 0.6.12

Open **Station Tools → Meter Calibration…**. References are saved with your
station settings and shared by the main console, large meter and RX scanners.
The screen can capture a fresh radio CAT sample or accept readings entered in
the table. Opening it stops running receive scans so the reference stays on one
frequency. Changing tabs requests the selected meter; closing restores your
previous meter selection. Calibration never keys the radio.

## Set VCC to your nominal 13.8 V

1. Connect CAT and open the **VCC · volts** tab.
2. Wait for **LIVE VCC CAT READING**. The reference field starts at **13.8**.
3. Click **ADD LIVE REFERENCE**, then **SAVE CALIBRATION**.
4. Select **VCC** on the main or large meter. It now reads in **V**, with a
   voltage scale instead of software counts.

This sets the captured reading to your chosen nominal voltage. A single
positive reference assumes CAT count zero represents zero volts, and scales
other readings proportionally. It cannot establish the supply's actual voltage
independently of your reference. If you can compare two measured voltage
levels, add both to correct an offset. Use **CLEAR THIS METER** to replace a
single-reference calibration with your measured pair; otherwise an existing
reference remains part of the curve.

## IC in amps

Use the **IC · amps** tab and enter the corresponding radio or external-meter
collector-current reading. Capture a fresh transmit-side CAT sample and save.
You control transmission using your usual station controls; the calibration
screen does not start it. One positive reference establishes a zero-based gain;
two or more references can correct an offset or changing slope.

IC means final-amplifier collector current. VCC means final-amplifier collector
voltage. They are radio measurements, separate from the USB sound card.
Until a reference is saved, a valid IC/VCC reply shows **CALIBRATE**. **RX IDLE**,
**NO DATA** and **STALE** retain their separate meanings.

## Match RX to the radio

The needle, printed scale and numeric reading now use one mapping. The number
follows the animated needle, including while signals rise and fall. A radio
sample in the established S0 range clears the needle and visual peak immediately.
An unavailable or expired reply clears the instrument and shows its status,
instead of presenting a fabricated S0 reading.

The retained default S scale is an estimate. To match your individual radio,
capture **S0** with the radio indicating no signal, then at least one higher
indication such as **S9**. Add other points, for example **S3**, **S7**,
**S9+20** and **S9+40**, to match the radio across its range. Fractional references
such as **S6.5** or **S9+15** are accepted. The first RX reference must be S0;
the highest accepted reference is S9+60. Clear the RX table and save to restore
the original default scale.

Increasing raw readings must correspond to increasing references. Duplicate,
reversed, missing, non-finite or out-of-range entries are rejected. Up to 32
reference points are supported per meter. Between references the application
interpolates; outside them it extends the nearest slope and identifies
extrapolated readings in the detail line. RX readings below the S0 reference
are clamped to zero. The display saturates at S9+60.

RX data comes from the radio's main S-meter CAT reply. Raw/processed AF, the
FFT, PC audio gain and the noise learner do not set its value. RX calibration
also updates the S-value and threshold mapping used by both scanner windows.

## Raw diagnostics and source

Raw CAT counts remain available in meter details and Meter Diagnostics for
comparison and troubleshooting. Diagnostics also records the saved IC/VCC
reference tables and identifies the RX mapping.

Yaesu documents F7 feedback as digitised meter deflection, with source selectors
for IC and VCC, rather than an amperes/volts conversion table. The physical
meaning of those meters is described in the front-panel section of the
[Yaesu Mark V Field operating manual](https://www.rigpix.com/yaesu/ft1000mpmarkvfield_manual.pdf).
The application's units therefore come from your station references.

![Calibration screen with a simulated 13.8 V reference](skin-previews-0.6.12/Meter-Calibration.png)
