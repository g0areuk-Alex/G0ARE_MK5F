G0ARE_MK5F World Map Data

The bundled country geometry is the 1:50m Natural Earth Admin 0 Countries
GeoJSON dataset, downloaded from the Natural Earth vector repository:

https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_50m_admin_0_countries.geojson
https://www.naturalearthdata.com/downloads/50m-cultural-vectors/50m-admin-0-countries/

Natural Earth data is public domain. The application uses the geometry
offline; it does not contact a map tile server or transmit station data to a
map provider. The small country code/prefix labels are application metadata,
not part of the Natural Earth dataset.
