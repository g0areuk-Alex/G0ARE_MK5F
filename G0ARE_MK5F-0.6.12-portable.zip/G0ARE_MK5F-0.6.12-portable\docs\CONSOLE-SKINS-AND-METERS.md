# Console skins and selectable meters — 0.6.12

Open **Console Presets** in the menu and select a design. This applies its layout
and skin together. **Themes** selects the layout alone; **Skins** selects the
palette and native instrument treatment alone. The original five layouts and
six skins remain available alongside these seven presets. Your choices are
saved in the existing station settings file.

| Preset | Appearance and arrangement |
| --- | --- |
| Broadcast 1978 | Wood case, brushed aluminium faceplate, recessed red LED display, raised dark buttons, cream analogue meters and full-width AF display |
| Paper Signal | Ivory paper, cobalt digits, thin rules, a vertical section rail, orange meter bars and a large black dial |
| Midnight Meridian | Navy and brass, stepped nautical frames, a larger centre dial, flanking tall meters and decorative navigation artwork |
| Bauhaus Signal | Bold black digits, red VFO strip, cobalt tuning panel, black AF display and yellow band buttons |
| Enterprise Bridge | LCARS-inspired left section rail, peach/lavender controls, large frequency and AF areas, right meter bars |
| Deep Space Tactical | Dark spacecraft instruments, cyan corner details and meter bars |
| Orbital Glass | Cool blue gradients, cyan digits, left instrument column and large AF area on the right |

These are native WinForms controls and drawing routines. No concept-image text
or fake buttons are used as controls. Band, mode, VFO, clarifier, tuning,
frequency entry and all nine advanced sections retain their existing event
handlers and radio/audio functions. Logbook, DX Cluster, SWL, Weather Fax,
large meter, scanner and World Map remain accessible. Every console now fits
the available window. Smaller windows rearrange the live banks into a compact
deck, and all sixteen launchers fit without scrolling. All sections still open
as resizable live windows.

The 0.6.9 renderer clears each complete button surface before painting a new
frame. This removes the stale captions and borders that appeared around the
earlier rounded buttons during live repainting. Material tiles and the detailed
dial face are cached; rotating the dial redraws its pointer without rebuilding
the material. The AF display's blue passband marks the current voice-filter
cutoffs only while that processing is enabled.

In the larger layouts, Broadcast and Meridian include a read-only display of the other VFO. It shows
**SELECT TO READ** until that VFO has been observed through normal CAT feedback,
then **LAST OBSERVED**. It never switches VFO or adds a polling command to obtain
an unseen frequency. The current selected VFO remains the primary live display.

## Meter buttons

The original receive S-meter stays in place. Above the transmit instrument,
select **PO, SWR, ALC, IC, VCC, MIC or TUN**. The large meter provides the same
choices plus **AUTO**, which restores its original RX signal / TX power mode.
Explicit large-meter choices and the main transmit-instrument choice are
synchronised. The selected source and large-meter AUTO preference are saved.

| Button | Source and presentation | Normal use |
| --- | --- | --- |
| PO | Existing RF-power mapping, auto 25 W AM / 100 W other modes or manual full scale | Existing primary power indication and SWR/ALC detail |
| SWR | Approximate linear SWR mapping, prefixed `~`, with raw CAT byte | Transmit |
| ALC | Relative 0–100% display with raw CAT byte; not calibrated | Transmit |
| IC | Collector current in amps using saved station references; CALIBRATE until set | Transmit |
| VCC | Collector voltage in volts using saved station references; ready to capture nominal 13.8 V | Requests a reply in receive or transmit; availability depends on the radio |
| MIC | Microphone meter raw CAT counts, 0–255 | Transmit |
| TUN | Tuner indication raw CAT counts, 0–255 | Transmit or an already active tuning operation |

Changing a source resets its visual peak marker. **STALE** means overall CAT
feedback is not current; **NO DATA** means this source has no valid reply;
**RX IDLE** means a transmit-only source is selected while receiving. A previous
source's value is never relabelled as the new source. Meter diagnostics include
the current selection, raw reply and visual deflection, while separately
reporting the original PO/SWR/ALC fields.

The meter buttons use the documented read-meter command (`F7`); they do not
change the physical radio meter selector or initiate PTT/ATU. PO, SWR and ALC
reuse existing poll samples. IC, VCC, MIC or TUN adds at most one read to the
existing background polling cycle. The selector bytes are PO `80`, ALC `81`,
IC `83`, VCC `84`, SWR `85`, MIC `86` and TUN `87` (hexadecimal), as listed in
the [Yaesu Mark V Field manual](https://public2024.yaesu.com/Files/4CB893D7-1018-01AF-FA97E9E9AD48B50C/MARK-V%20Field_Spanish.pdf).

The extra selectors are verified against the documented packets and simulator.
Compare replies and indications with the physical station before relying on
them. **Station Tools → Meter Calibration…** now captures station references
for IC in amps and VCC in volts. The VCC reference starts at **13.8 V**. One
positive reference assumes CAT zero equals physical zero; multiple references
can correct an offset. Raw counts remain available in details and diagnostics.
See the [calibration instructions](METER-CALIBRATION.md).

The RX S-value follows the animated needle and all scale labels use its shared
mapping. Genuine S0 readings clear the needle immediately; unavailable or
expired feedback shows its separate status. Saved RX references match your
radio's S indications and also feed both scanners.

## Fitting the screen and tuning

Maximise the window or press **F11** for the existing full-screen view. The
console also fits smaller windows, down to 800 × 560 pixels. Large layouts
retain their design-specific arrangements; smaller windows use a compact
deck with all original controls. Paper and Enterprise keep their section rail
when there is enough width. Compact instruments use a bar scale and the same
live source, readout and peak mapping; large instruments retain their normal
faces. Shorter launcher captions keep the full name in HoverHelp.

Hover a frequency digit and turn the wheel. Each notch uses its place value:
10 MHz, 1 MHz, 100 kHz, 10 kHz, 1 kHz, 100 Hz or 10 Hz. The last Hz digit also
uses 10 Hz because the Mark V frequency-set CAT command encodes 10 Hz units.
The hovered digit is underlined and its step appears in the display footer.
The dial and the empty area around the digits use the selected tuning step.
Multiple notches and high-resolution partial notches are supported. The console
does not scroll, even when another main-console panel has focus. Double-click
entry and dial dragging still work.

The menu has a separate measured row with room below its lettering. The MK5F
logo stays visible at the top left in full screen, and all application windows
use the MK5F icon.

Below START/STOP AF, **RAW AF** selects playback before the PC's RX DSP and the
raw spectrum; **PROCESSED AF** selects the noise-reduced, filtered/EQ audio and
processed spectrum. Both use the Audio window's selected output, monitor gain
and limiter. Switching keeps the same capture/output handles; the next PCM
block uses the chosen source. Click the active button again for monitor OFF.
**LEARN** starts the same noise-floor learner as **LEARN NOISE** in the Audio
window, shows **LEARNING** while it runs, and becomes available again when it
finishes. These shortcuts become available once AF capture or simulated AF is
running. All Audio window controls remain, including its independent RAW FFT
checkbox. Morse decoding, recording and weatherfax continue using processed AF.

## App-rendered previews

These renders use simulated display data in safe mode. CAT and Windows audio
are not connected. Native combo selection text is included from the live
control values because WinForms `DrawToBitmap` omits that native text.

![Broadcast 1978](skin-previews-0.6.12/Broadcast-1978.png)

![Paper Signal](skin-previews-0.6.12/Paper-Signal.png)

![Midnight Meridian](skin-previews-0.6.12/Midnight-Meridian.png)

![Bauhaus Signal](skin-previews-0.6.12/Bauhaus-Signal.png)

![Enterprise Bridge](skin-previews-0.6.12/Enterprise-Bridge.png)

![Deep Space Tactical](skin-previews-0.6.12/Deep-Space-Tactical.png)

![Orbital Glass](skin-previews-0.6.12/Orbital-Glass.png)

![Selectable SWR meter](skin-previews-0.6.12/Meter-SWR.png)

![Selectable ALC meter](skin-previews-0.6.12/Meter-ALC.png)

![Selectable IC meter](skin-previews-0.6.12/Meter-IC.png)

![Selectable VCC meter](skin-previews-0.6.12/Meter-VCC.png)

Compact examples use a 1366 × 728 window to leave room for the Windows taskbar:

![Compact Broadcast console](viewport-previews-0.6.12/Broadcast-1978.png)

![Compact Enterprise console](viewport-previews-0.6.12/Enterprise-Bridge.png)

To regenerate safely, run
`G0ARE_MK5F.exe --appearance-preview OUTPUT_DIRECTORY --preview-size 1366x728`.
For the independent viewport/wheel regression, run `G0ARE_MK5F.exe --viewport-test`.
