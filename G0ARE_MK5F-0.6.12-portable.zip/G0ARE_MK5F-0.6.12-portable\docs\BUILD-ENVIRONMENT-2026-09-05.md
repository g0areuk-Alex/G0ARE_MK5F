# G0ARE_MK5F — build, runtime and dependency inventory

Date captured: 3 October 2026  
Product baseline: v0.6.3 engineering release  
Source revision: not available; this workspace has no Git metadata or other
revision identifier.

This is an as-built inventory for the supplied workspace. It records what was
observed locally; it is not a clean-machine support matrix and does not prove
physical-radio or Windows-device compatibility.

## Build host and target

| Item | Observed value | Evidence / limitation |
|---|---|---|
| Host OS registry label | `Windows 10 Home` | Windows registry `ProductName`; this host reports `DisplayVersion=25H2`, `CurrentBuild=26200`, `UBR=9278`, and `OSVersion=10.0.26200.0`. The project metadata calls the target Windows 11; the product label/build combination needs confirmation on a supported clean machine. |
| Host architecture | 64-bit operating system | `[Environment]::Is64BitOperatingSystem=True`; the executable is compiled `/platform:anycpu`. No separate 32-bit execution matrix was run. |
| Installed framework/compiler | .NET Framework registry release `533509`; `C:\WINDOWS\Microsoft.NET\Framework64\v4.0.30319\csc.exe`, version `4.8.9221.0` | The compiler was selected by `BUILD-WINDOWS.bat`; the build log is authoritative for each run. |
| Application manifest | Assembly version `0.6.3.0`, `asInvoker`, Windows compatibility GUID for Windows 10 | The application and compiled setup stub request no elevation; the installer performs a per-user install. |
| Compiler references | `System.dll`, `System.Core.dll`, `System.Drawing.dll`, `System.Windows.Forms.dll` | Declared directly by `BUILD-WINDOWS.bat`; no solution/project file or package-lock file is present. |

## Native and external surfaces

| Surface | Implementation found | Operational boundary |
|---|---|---|
| CAT serial | `System.IO.Ports.SerialPort`, 4800 baud, 8 data bits, no parity, 2 stop bits | Opens only after the operator requests CAT connection; physical Field interoperability remains unverified. |
| Receive audio | Windows `winmm.dll` wave-in APIs in `AudioAndDsp.cs` | Friendly name and wave-device ID are persisted together and must match before automatic reuse. Endpoint/channel/rate and unplug/replug behaviour require station testing. SCU-17 input is rejected by the console's live AF path. |
| Local playback | Windows `winmm.dll` wave-out APIs in `RxAudioProcessing.cs` | Friendly name and wave-device ID are persisted together and must match before automatic reuse. Replay/practice are explicitly local-output paths; actual routing and feedback behaviour remain integration-open. |
| UI/process support | Windows Forms and `user32.dll` | Windows-only desktop executable; no service, driver or elevation component was found. |
| Optional network | `System.Net.Sockets.TcpClient` in the DX-cluster window, bounded `System.Net` schedule retrieval in `SwlStation.cs` and the `System.Net` HTTPS manifest/package client in `ReleaseAndUpdate.cs` | Manual user-selected Telnet host/port, a bounded seasonal EiBi station-schedule refresh and an operator-configured release feed; HTTPS is required for remote update sources, with loopback/local files available for controlled tests. No cloud backend, telemetry client or authentication service is present. Endpoint reachability, feed ownership and station/list-provider policy remain unverified. |
| Data storage | CSV logbook, ADIF interchange, versioned non-secret settings, operator profile and data-only backup manifests | No database engine was found. Restore/import paths are bounded and tested locally; clean-user/PC recovery is still open. |

No NAudio, SQLite, Hamlib, NuGet package, third-party runtime or signing key was
found in the workspace. The installer is a compiled local stub rather than a
third-party framework; the updater is a PowerShell post-exit helper. This
statement is an inventory result, not a security guarantee for an arbitrary
future binary.

The SWL catalogue is a local data feature, not an internet-radio streaming
client. The default schedule source is the current seasonal EiBi text feed;
authorised CSV/TSV/semicolon exports can be imported for other station lists.
Provider accounts or manual exports may be required, and the FT-1000MP Mark V
Field tuning guard remains 0.1–30 MHz.

## Repeatable local procedure

From the project root on Windows:

```text
BUILD-WINDOWS.bat --no-pause
```

The script locates the .NET Framework C# compiler, compiles every `src\*.cs`
file with warning level 4, emits `dist\G0ARE_MK5F.exe`, and runs the built-in
self-test. The normal interactive form is `BUILD-WINDOWS.bat`.

For the portable engineering bundle:

```text
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\PACKAGE-PORTABLE.ps1
```

The package script rebuilds and self-tests unless `-SkipBuild` is explicitly
used, then emits the ZIP, a SHA-256 sidecar, a release manifest and a
content-addressed source-input manifest. The bundle is unsigned. To build the
single-file setup package, run:

```text
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\PACKAGE-INSTALLER.ps1
```

This first refreshes the portable stage, then compiles an icon-bearing setup
stub with the payload embedded. The local update service consumes a maintainer-
hosted manifest matching `UPDATE-MANIFEST.example.json`; no public feed or
signing infrastructure is present in this workspace.

## Provenance limits

The source manifest covers the build/package scripts, icon, installer stub,
setup/update helpers, `app.manifest`, `VERSION.txt`, map data and every
`src\*.cs` input. It cannot establish a
repository revision because none is available. The current evidence therefore
supports repeatable local reconstruction and artifact hashing, but not clean-
machine reproducibility, publisher identity, signed-release provenance or the
full station acceptance gates in the handover.
