# G0ARE_MK5F 0.6.12 — RX meter agreement and station calibration

The RX S-value and needle previously used different scale-label spacing. The
number also updated immediately while the needle moved smoothly. This release
positions every RX scale label using the shared mapping and derives the number
from the animated needle. The change applies to all skins, compact meters and
the large meter's receive AUTO mode.

- Radio S0 readings clear the needle and visual peak immediately. Missing or
  expired replies show **NO DATA** or **STALE**, with the instrument cleared.
- **Station Tools → Meter Calibration…** captures live references or accepts
  manually entered pairs for RX, VCC and IC. Scans stop while calibrating, and
  the original meter selection is restored on closing the screen.
- VCC starts with a **13.8 V** reference ready to capture. After saving, VCC
  displays volts and IC displays amps on matching physical-unit scales.
- One positive VCC/IC reference assumes a zero-based conversion. Two or more
  can correct an offset or changing slope. Unsupplied references show
  **CALIBRATE**; physical units are not fabricated.
- Calibration survives restart and is shared by the main/large instruments.
  RX references also feed the band and SWL scanner S-value/threshold mapping.
- Raw CAT counts and saved calibration tables remain available for diagnosis.
- Closing now blocks input with one lightweight closing screen, avoiding the
  synchronous delay from disabling hundreds of console controls. Device release
  and independent PTT OFF remain in the background.

See [the calibration instructions](docs/METER-CALIBRATION.md) for the 13.8 V
capture procedure and RX/current references.

All 0.6.11 controls, themes, digit-wheel tuning, full-screen branding and AF
shortcuts are retained. Calibration uses read-only CAT polling and does not
request transmission. Nominal 13.8 V is an operator reference; hardware accuracy
depends on the radio/external readings used for calibration.

Validation is recorded in [the release checks](docs/SKIN-RELEASE-CHECKS-0.6.12.md).
